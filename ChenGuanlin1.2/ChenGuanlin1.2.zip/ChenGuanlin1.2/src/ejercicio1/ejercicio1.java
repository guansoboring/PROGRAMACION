package ejercicio1;
import java.util.Scanner;

public class ejercicio1 {

	public static void main (String[] args) {
		// TODO Auto-generated method stub
      Scanner input = new Scanner(System.in);
      System.out.println("Introduce tu nombre");
      String nombre = input.nextLine();

      System.out.println("Introduce tu apellidos");
      String apellidos = input.nextLine();

      System.out.println("Introduce tu edad");
      int edad = input.nextInt();
      input.nextLine();

      System.out.println("Introduce tu dirección");
      String direccion = input.nextLine();

      System.out.println("Introduce tu altura(m)");
      double altura = input.nextDouble();

      System.out.println("Introduce tu peso(kg)");
      double peso = input.nextDouble();

      System.out.println( nombre+","+apellidos+","+edad+","+direccion+","+altura+","+peso);
	}
}
